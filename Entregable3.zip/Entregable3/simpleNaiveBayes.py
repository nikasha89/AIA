import csv
import random
import math



def loadCsv(filename):
    lines = csv.reader(open(filename, "rb"))
    dataset = list(lines)
    for i in range(len(dataset)):
        dataset[i] = [float(x) for x in dataset[i]]
    return dataset


def splitDataset(dataset, splitRatio):
    trainSize = int(len(dataset) * splitRatio)
    trainSet = []
    copy = list(dataset)
    while len(trainSet) < trainSize:
        index = random.randrange(len(copy))
        trainSet.append(copy.pop(index))
    return [trainSet, copy]


def separateByClass(dataset):
    separated = {}
    for i in range(len(dataset)):
        vector = dataset[i]
        if (vector[-1] not in separated):
            separated[vector[-1]] = []
        separated[vector[-1]].append(vector)
    return separated


def mean(numbers):
    return sum(numbers) / float(len(numbers))


def stdev(numbers):
    avg = mean(numbers)
    variance = sum([pow(x - avg, 2) for x in numbers]) / float(len(numbers) - 1)
    return math.sqrt(variance)


def summarize(dataset):
    summaries = [(mean(attribute), stdev(attribute)) for attribute in zip(*dataset)]
    del summaries[-1]
    return summaries


def summarizeByClass(dataset):
    separated = separateByClass(dataset)
    summaries = {}
    for classValue, instances in separated.items():
        summaries[classValue] = summarize(instances)
    return summaries


def calculateProbability(x, mean, stdev):
    exponent = math.exp(-(math.pow(x - mean, 2) / (2 * math.pow(stdev, 2))))
    return (1 / (math.sqrt(2 * math.pi) * stdev)) * exponent


def calculateClassProbabilities(summaries, inputVector):
    probabilities = {}
    for classValue, classSummaries in summaries.items():
        probabilities[classValue] = 1
        for i in range(len(classSummaries)):
            mean, stdev = classSummaries[i]
            x = inputVector[i]
            probabilities[classValue] *= calculateProbability(x, mean, stdev)
    return probabilities


def predict(summaries, inputVector):
    probabilities = calculateClassProbabilities(summaries, inputVector)
    bestLabel, bestProb = None, -1
    for classValue, probability in probabilities.items():
        if bestLabel is None or probability > bestProb:
            bestProb = probability
            bestLabel = classValue
    return bestLabel


def getPredictions(summaries, testSet):
    predictions = []
    for i in range(len(testSet)):
        result = predict(summaries, testSet[i])
        predictions.append(result)
    return predictions


def getAccuracy(testSet, predictions):
    correct = 0
    for i in range(len(testSet)):
        if testSet[i][-1] == predictions[i]:
            correct += 1
    return (correct / float(len(testSet))) * 100.0


def main():
    filename = 'pima-indians-diabetes.data.csv'
    splitRatio = 0.67
    dataset = loadCsv(filename)
    trainingSet, testSet = splitDataset(dataset, splitRatio)
    print('Split {0} rows into train={1} and test={2} rows').format(len(dataset), len(trainingSet), len(testSet))
    # prepare model
    summaries = summarizeByClass(trainingSet)
    # test model
    predictions = getPredictions(summaries, testSet)
    accuracy = getAccuracy(testSet, predictions)
    print('Accuracy: {0}%').format(accuracy)
def _contents(self, data, laplace):
    # count occurrences of values:
    counts = []
    for row in range(len(data)):
        counts_ = []
        for item in range(len(data[row])):
            counts_.append(data.count(item))
        counts.append(counts_)
    # suavizado laplace y logaritmo:
    for k in range(len(counts)):
        # Obtenemos la columna donde obtendremos las ocurrencias de cada valor:
        fila = np.array(data)[k, :]
        # Obtenemos en un diccionario todas las probabilidades asociadas a cada valor:
        dict_P_vj_ai = collections.Counter(fila)
        for prob in range(len(counts[k])):
            probAux = counts[k][prob]
            if laplace:
                # log_P_vj = log(ocurencias de valor en el conjunto de datos/total elementos)
                log_P_vj = math.log((probAux + self.k) / (len(data) * len(data[0]) + len(data[0]) * self.k), 10)
                # P_vj_aj = log(ocurrencias de valor en columna + k dividido entre total elementos de la fila + totalAtributos*k)
                log_P_vj_aj = math.log((dict_P_vj_ai[data[k][prob]] + self.k) / (len(data[0]) + len(data[0]) * self.k),
                                       10)
                counts[k][prob] = log_P_vj + log_P_vj_aj
            else:
                log_P_vj = math.log((probAux) / (len(data) * len(data[0])), 10)
                log_P_vj_aj = math.log((dict_P_vj_ai[data[k][prob]]) / (len(data) * len(data[0])), 10)
                counts[k][prob] = log_P_vj + log_P_vj_aj
    return counts


main()

"""
    def prepara_datos_entrada(self, data):
        listAux = []
        for row in range(len(data)):
            listAux_= []
            for voto in range(len(data[row])):
                if data[row][voto] == "s":
                    listAux_.append(1)
                elif data[row][voto] == "n":
                    listAux_.append(0.1)
                else:
                    listAux_.append(0.01)
            listAux.append(listAux_)
        return listAux
"""
""" 
        for row in range(len(data)):
            counts_ = []
        for item in range(len(data[row])):
            valueAux = 0.0
            # Si ese índice está dentro de counts tomamos el valor de su contenido:
            if row in range(len(counts)) and item in range(len(counts[row][item])):
                valueAux = counts[row][item]
            counts_.append(valueAux + 1.0)
        counts.append(counts_)
        #print(str(counts))    
        Por partido político
        for k in range(len(counts)):
            dict_P_vj_ai = {}
            for prob in range(len(counts[k])):
                if prob == 0:
                    #Obtenemos la columna donde obtendremos las ocurrencias de cada valor:
                    columna = np.array(data)[:, prob]
                    # Obtenemos en un diccionario todas las probabilidades asociadas a cada valor:
                    dict_P_vj_ai = collections.Counter(columna)
                probAux = counts[k][prob]
                if laplace:
                    #log_P_vj = log(ocurencias de valor en el conjunto de datos/total elementos)
                    log_P_vj = math.log((probAux + self.k)/(len(data)*len(data[0])+ len(data[0])*self.k),10)
                    #P_vj_aj = log(ocurrencias de valor en columna + k dividido entre total elementos + totalAtributos*k)
                    log_P_vj_aj = math.log((dict_P_vj_ai[data[k][prob]] + self.k)/(len(data)*len(data[0]) + len(data[0])*self.k),10)
                    counts[k][prob] = log_P_vj + log_P_vj_aj
                else:
                    log_P_vj = math.log((probAux) / (len(data) * len(data[0])), 10)
                    log_P_vj_aj = math.log((dict_P_vj_ai[data[k][prob]]) / (len(data) * len(data[0])), 10)
                    counts[k][prob] = log_P_vj + log_P_vj_aj
"""