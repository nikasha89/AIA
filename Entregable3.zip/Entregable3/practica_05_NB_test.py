import practica_05_NB as pract

# ---------------------------------------------------------------------------
""" 
Caso Ejemplo Simple Naive Bayes, datos por defecto: votes.py
"""
# ---------------------------------------------------------------------------

p = pract.ClasificadorNaiveBayes(3)
#print(str(p._contents(p.valores_atributos)))
#print(str(p._contents(p.valores_atributos,False)))
#print(p.SimpleNB())
#print(p.entrena(True))
print(p.clasifica())